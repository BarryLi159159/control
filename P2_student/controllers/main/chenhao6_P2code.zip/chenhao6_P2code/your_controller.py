# Import libraries
import numpy as np
from base_controller import BaseController
from scipy import signal, linalg
from util import *

# Custom Controller Class
class CustomController(BaseController):
    def __init__(self, trajectory):
        super().__init__(trajectory)
        
        # Define constants for the vehicle dynamics
        self.lr = 1.39
        self.lf = 1.55
        self.Ca = 20000
        self.Iz = 25854
        self.m = 1888.6
        self.g = 9.81
        
        # Initialize PID and additional variables for control
        self.integralPsiError = 0
        self.previousPsiError = 0
        self.integralXdotError = 0
        self.previousXdotError = 0
        self.trajectory = trajectory
        self.K = None  # Placeholder for lateral gain matrix

        # Set up the lateral controller gain matrix K
        self.setup_lateral_controller()

    def setup_lateral_controller(self):
        """Designs the state feedback gain matrix K for the lateral controller using pole placement."""
        # Define the lateral state-space model matrices
        A = np.array([
            [0, 1, 0, 0],
            [0, -2 * self.Ca / (self.m * self.lf), 2 * self.Ca / self.m, -2 * self.Ca * (self.lf - self.lr) / (self.m * self.lf)],
            [0, 0, 0, 1],
            [0, -2 * self.Ca * (self.lf - self.lr) / (self.Iz * self.lf), 2 * self.Ca * (self.lf - self.lr) / self.Iz, -2 * self.Ca * (self.lf**2 + self.lr**2) / (self.Iz * self.lf)]
        ])
        B = np.array([[0], [2 * self.Ca / self.m], [0], [2 * self.Ca * self.lf / self.Iz]])

        # Desired poles for the closed-loop system 
        desired_poles = [-1, -1.5, -2, -2.5]
        self.K = signal.place_poles(A, B, desired_poles).gain_matrix

    def update(self, timestep):
        # Fetch the states from the BaseController method
        delT, X, Y, xdot, ydot, psi, psidot = super().getStates(timestep)

        # ---------------|Lateral Controller|-------------------------
        # Find the closest node to the vehicle
        _, node = closestNode(X, Y, self.trajectory)
        forwardIndex = 50  # Node index ahead of the current position

        # Calculate the desired heading angle psiDesired
        try:
            psiDesired = np.arctan2(self.trajectory[node + forwardIndex, 1] - Y, 
                                    self.trajectory[node + forwardIndex, 0] - X)
        except:
            psiDesired = np.arctan2(self.trajectory[-1, 1] - Y, 
                                    self.trajectory[-1, 0] - X)

        # PID gains for the lateral controller
        kp = 1
        ki = 0.005
        kd = 0.001

        # Calculate the heading angle error for lateral control
        psiError = wrapToPi(psiDesired - psi)
        self.integralPsiError += psiError * delT
        derivativePsiError = (psiError - self.previousPsiError) / delT
        self.previousPsiError = psiError

        # Calculate delta (steering angle) using the PID controller
        delta = kp * psiError + ki * self.integralPsiError + kd * derivativePsiError
        delta = wrapToPi(delta)  # Ensure delta is within bounds

        # ---------------|Longitudinal Controller|-------------------------
        # PID gains for longitudinal control
        kp_long = 200
        ki_long = 10
        kd_long = 30

        # Target velocity for the longitudinal control
        desiredVelocity = 6  # Target speed in m/s
        xdotError = desiredVelocity - xdot
        self.integralXdotError += xdotError * delT
        derivativeXdotError = (xdotError - self.previousXdotError) / delT
        self.previousXdotError = xdotError

        # Calculate F (force) using the PID controller for longitudinal control
        F = kp_long * xdotError + ki_long * self.integralXdotError + kd_long * derivativeXdotError

        # Return all states and calculated control inputs (F, delta)
        return X, Y, xdot, ydot, psi, psidot, F, delta
